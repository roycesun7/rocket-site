export const DB1 = {
    title: "Our Mission",
    text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent porttitor sem arcu, vitae luctus nibh condimentum et.",
    button: "More about us",
    href: "/",
}

export const DB2 = {
    title: "Our Story",
    text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent porttitor sem arcu, vitae luctus nibh condimentum et.",
    button: "Learn about the team",
    href: "/asdfasdfa",
}

export const TC1 = {
    titleA: "Our Current Projects",
    textA: "See our latest work",
    hrefA: "a",
    buttonA: "Learn More",
    titleB: "Our Past Projects",
    textB: "Look at our history",
    hrefB: "b",
    buttonB: "Explore",
    titleC: "Photo Gallery",
    textC: "Enjoy a collection of hand-picked photos of our team",
    hrefC: "c",
    buttonC: "Check it out",
}

export const Q1 = {
    text: "We choose to go to the moon in this decade and do the other things, not because they are easy, but because they are hard.",
    person: "John F. Kennedy",
}